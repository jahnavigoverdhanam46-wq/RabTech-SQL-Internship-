# Business Rule-to-Constraint Matrix

**Project:** Business Rules to Executable Relational Model  
**Database:** PostgreSQL (`rabtech_internship`)

**Note:** The following rules are proposed design assumptions because the supplied brief does not specify the detailed internship-management rules.

| Rule ID | Business rule | Table | Database enforcement | Negative test |
|---|---|---|---|---|
| BR-01 | Each intern must have a unique email address. | `interns` | `UNIQUE (email)` | Duplicate email rejected |
| BR-02 | An internship program's end date cannot be earlier than its start date. | `internship_programs` | `CHECK (end_date >= start_date)` | Invalid date range rejected |
| BR-03 | A program status must be one of `PLANNED`, `ACTIVE`, `COMPLETED`, or `CANCELLED`. | `internship_programs` | `CHECK` constraint on `program_status` | Invalid status rejected |
| BR-04 | An intern cannot enroll in the same program more than once. | `enrollments` | `UNIQUE (intern_id, program_id)` | Duplicate enrollment should be rejected |
| BR-05 | A submission score, when provided, must be between 0 and 100. | `task_submissions` | `CHECK (score IS NULL OR score BETWEEN 0 AND 100)` | Negative score rejected |

## Other database invariants

- Primary keys uniquely identify records in each table.
- Foreign keys ensure that enrollments reference existing interns and programs.
- Tasks reference existing internship programs.
- Submissions reference existing enrollments and tasks.
- `ON DELETE RESTRICT` prevents deleting referenced records.
- Status columns accept only their explicitly permitted values.

## Transaction and migration notes

- The initial schema migration groups table creation inside a transaction.
- The seed fixture inserts representative sample records.
- Negative SQL tests are run individually because each invalid statement is expected to fail.
- The initial migration uses `CREATE TABLE IF NOT EXISTS`. This avoids errors when tables already exist, but does not verify that existing table definitions match the migration.

## Known design limitation

The current `task_submissions` schema checks that an enrollment and a task both exist, but does not enforce that the task belongs to the same program as the enrollment. This cross-table business rule would need additional database enforcement if required by the final domain requirements.
