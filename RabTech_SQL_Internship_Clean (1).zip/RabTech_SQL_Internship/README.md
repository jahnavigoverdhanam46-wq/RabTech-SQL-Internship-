# Internship Management Database Project

## 1. Project Overview
This project implements an initial relational database schema for managing internship programs, interns, enrollments, tasks, and task submissions using PostgreSQL.

## 2. Technologies Used
- PostgreSQL
- pgAdmin 4
- Visual Studio Code
- SQL
- Mermaid ER Diagram

## 3. Database Entities
1. **Interns** — stores intern details.
2. **Internship Programs** — stores program details, dates, and status.
3. **Enrollments** — links interns to internship programs.
4. **Internship Tasks** — stores tasks associated with programs.
5. **Task Submissions** — stores submissions, review status, and scores.

## 4. Business Rules
1. Each intern must have a unique email address.
2. A program's end date cannot be earlier than its start date.
3. Program status must be PLANNED, ACTIVE, COMPLETED, or CANCELLED.
4. An intern cannot enroll in the same program more than once.
5. A submission score, when provided, must be between 0 and 100.

## 5. Project Files
- `01_ER_Diagram/` — ER diagram and source.
- `02_Rule_Matrix/` — business rule-to-constraint mapping.
- `03_Migrations/` — database schema migration SQL.
- `04_Fixtures/` — representative seed data.
- `05_Negative_Tests/` — SQL tests for invalid data.

## 6. Testing
Negative SQL tests were executed to verify that invalid data is rejected by database constraints, including duplicate emails, blank names, invalid program dates, invalid program statuses, and negative submission scores.

## 7. Assumptions and Limitations
The internship-management entities and business rules are working assumptions for this training project. The detailed business narrative was not available for confirmation.

The initial migration uses `CREATE TABLE IF NOT EXISTS`. This helps avoid recreating existing tables, but it does not by itself provide full migration version tracking or verify that existing tables match the intended schema.

The current schema also does not enforce that a submitted task belongs to the same program as the enrollment associated with that submission.

## 8. Entity States and Cardinalities

### Entity States

- **Interns:** An intern record remains stored after creation; no active/inactive status is currently defined.
- **Internship Programs:** PLANNED, ACTIVE, COMPLETED, CANCELLED.
- **Enrollments:** ENROLLED, WITHDRAWN, COMPLETED.
- **Internship Tasks:** OPEN, CLOSED.
- **Task Submissions:** SUBMITTED, UNDER_REVIEW, ACCEPTED, REJECTED.

### Relationship Cardinalities

1. One intern can have zero or many enrollments; each enrollment belongs to one intern.
2. One internship program can have zero or many enrollments; each enrollment belongs to one program.
3. One program can contain zero or many tasks; each task belongs to one program.
4. One enrollment can have zero or many task submissions.
5. One task can receive zero or many task submissions.

## 9. Data Retention Needs

The exact retention period has not been specified in the available project requirements. The following are proposed requirements and need confirmation:

- Retain intern records while they are needed for internship administration and auditing.
- Retain program and enrollment history to track participation and completion.
- Retain task and submission records, including review status and scores, for assessment and audit purposes.
- Define a retention period and deletion or anonymization procedure before using this database in production.