-- Negative SQL tests
-- Each test should fail because of a database constraint.
-- Run each test separately in pgAdmin.

-- TEST 1: Duplicate email must be rejected
INSERT INTO interns (full_name, email)
VALUES ('Duplicate Email Test', 'aarav.test@example.com');

-- TEST 2: Empty name must be rejected
INSERT INTO interns (full_name, email)
VALUES ('   ', 'emptyname.test@example.com');

-- TEST 3: End date before start date must be rejected
INSERT INTO internship_programs
    (program_name, domain, start_date, end_date, program_status)
VALUES
    ('Invalid Date Test', 'Testing', '2026-11-20', '2026-11-10', 'PLANNED');

-- TEST 4: Invalid program status must be rejected
INSERT INTO internship_programs
    (program_name, domain, start_date, end_date, program_status)
VALUES
    ('Invalid Status Test', 'Testing', '2026-11-01', '2026-11-10', 'INVALID');

-- TEST 5: Negative task score must be rejected
-- This test will be added after we create a valid task submission.
-- Test results:
-- TEST 1: Duplicate email - PASS
-- TEST 2: Blank intern name - PASS
-- TEST 3: Invalid program date range - PASS
-- TEST 4: Invalid program status - PASS
-- TEST 5: Negative submission score - PASS