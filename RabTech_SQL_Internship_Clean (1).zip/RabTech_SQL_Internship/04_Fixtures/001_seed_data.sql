-- Seed fixtures: representative internship-management data
-- Assumption: these sample records are for database testing.

BEGIN;

INSERT INTO interns (full_name, email)
VALUES
    ('Aarav Mehta', 'aarav.test@example.com'),
    ('Diya Nair', 'diya.test@example.com'),
    ('Kabir Shah', 'kabir.test@example.com');

INSERT INTO internship_programs
    (program_name, domain, start_date, end_date, program_status)
VALUES
    ('SQL and Database Engineering', 'Database', '2026-10-13', '2026-10-14', 'COMPLETED'),
    ('Python Development', 'Programming', '2026-10-20', '2026-11-20', 'PLANNED');

INSERT INTO enrollments (intern_id, program_id, enrolled_on)
SELECT i.intern_id, p.program_id, DATE '2026-10-13'
FROM interns i
CROSS JOIN internship_programs p
WHERE i.email = 'aarav.test@example.com'
  AND p.program_name = 'SQL and Database Engineering';

INSERT INTO enrollments (intern_id, program_id, enrolled_on)
SELECT i.intern_id, p.program_id, DATE '2026-10-20'
FROM interns i
CROSS JOIN internship_programs p
WHERE i.email = 'diya.test@example.com'
  AND p.program_name = 'Python Development';

INSERT INTO internship_tasks (program_id, task_title, due_date)
SELECT program_id, 'Design a relational schema', DATE '2026-10-14'
FROM internship_programs
WHERE program_name = 'SQL and Database Engineering';

INSERT INTO internship_tasks (program_id, task_title, due_date)
SELECT program_id, 'Write basic Python programs', DATE '2026-11-01'
FROM internship_programs
WHERE program_name = 'Python Development';

COMMIT;